package geese_and_turkeys.behavior;

public interface Goose_n_Turkey_Behavior {//Weapon behavior
	public String makeNoise();	
// HONK! howk. Quack! 
// Gobble. Yelp! cluck.
}
