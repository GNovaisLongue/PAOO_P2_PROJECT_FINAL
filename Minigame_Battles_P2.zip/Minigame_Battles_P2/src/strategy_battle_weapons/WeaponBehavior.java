package strategy_battle_weapons;

public interface WeaponBehavior {
	public double useWeapon(); //dano da arma
	public String toString();
}
